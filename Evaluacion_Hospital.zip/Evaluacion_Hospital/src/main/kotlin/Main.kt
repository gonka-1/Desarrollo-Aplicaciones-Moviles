package org.example

import kotlinx.coroutines.delay
import org.example.model.*
import kotlinx.coroutines.*

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() = runBlocking {
    val boxN = Box("FG;", "Jose", "14-09-2026", TipoPaciente.Fonasa)
    val box1 = BoxGeneral("GF7", "Pedro", "14-09-2026", TipoPaciente.Isapre)
    val box2 = BoxEspecialidad("GF7", "Pedro", "14-09-2026", TipoPaciente.Isapre, true)
    val espacio = Espacio(1, box1, Estado.Ocupado)


    val espacios = mutableListOf(espacio)

    suspend fun ingresar(boxNuevo: Box){
        if(espacios.count()>=10){
            println("No hay espacios")
            return
        }
        var espacio = Espacio(2, box1, Estado.EnProceso)
        delay(2500)
        espacio = Espacio(2, box1, Estado.Ocupado)
        espacios.add(espacio)
    }

    suspend fun salir(box: Box, minutos: Int){
       //cobrar tarifa
        var espacio = Espacio(2, box1, Estado.EnProceso)
        delay(2500)
        espacio = Espacio(2, box1, Estado.Libre)
        box.tarifa(minutos)
    }

    fun verEspacios(){
        for(espacio in espacios){
            println("${espacio.codigo} se encuentra en estado ${espacio.estado}")
        }
    }

    try {
        verEspacios()
        ingresar(box2)
        salir(box2, 25)
        verEspacios()
    }
    catch (e: Exception){
        println(e.message)
    }
}

