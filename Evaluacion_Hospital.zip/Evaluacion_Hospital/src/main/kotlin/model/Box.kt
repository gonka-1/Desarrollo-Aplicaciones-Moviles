package org.example.model

open class Box(
    val codigo: String,
    val nombre: String,
    val fecha: String,
    val tipoPaciente: TipoPaciente
){
    open fun tarifa(minutos: Int, ): Double{
        //no se usa podría ser abstract
        return 0.0;
    }
}

class BoxGeneral(
    codigo: String,
    nombre: String,
    fecha: String,
    tipoPaciente: TipoPaciente
):Box(codigo, nombre, fecha, tipoPaciente) {
    //tarifa 8000
    val tarifa = 8000
    override fun tarifa(minutos: Int): Double {
        var total = tarifa * (minutos/60.0)

        if(tipoPaciente == TipoPaciente.Isapre){
            total = 0.8 * total

        }

        println("tarifa: $total")

        return total;
    }
}

class BoxUrgenncia(
    codigo: String,
    nombre: String,
    fecha: String,
    tipoPaciente: TipoPaciente
):Box(codigo, nombre, fecha, tipoPaciente) {
    //tarifa de 15000 por hora
    val tarifa = 15000
    override fun tarifa(minutos: Int): Double {
        var total = tarifa * (minutos/60.0)

        if(tipoPaciente == TipoPaciente.Isapre){
            total = 0.8 * total

        }
        println("tarifa: $total")

        return total;
    }
}

class BoxEspecialidad(
    codigo: String,
    nombre: String,
    fecha: String,
    tipoPaciente: TipoPaciente,
    val quirurguico : Boolean
):Box(codigo, nombre, fecha, tipoPaciente) {
    //tarifa de 25000
    //si es quirurguico -> 30%

    val tarifa = 25000
    override fun tarifa(minutos: Int): Double {
        var total = tarifa * (minutos/60.0)

        if(quirurguico){
            total = 1.3 * total

        }
        println("tarifa: $total")
        return total;
    }
}