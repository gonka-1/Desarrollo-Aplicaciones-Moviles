package org.example.model

class Espacio(
    val codigo: Int,
    val box: Box,
    val estado: Estado
)