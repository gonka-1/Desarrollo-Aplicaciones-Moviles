package org.example.model

sealed class Estado(){
    data object Libre: Estado()
    data object Ocupado: Estado()
    data object EnProceso: Estado()
    data object FueraDeServicio : Estado()

}