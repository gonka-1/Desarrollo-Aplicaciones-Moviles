package org.example.model

sealed class TipoPaciente (){
    data object Fonasa: TipoPaciente()
    data object Isapre: TipoPaciente()
    data object Particular: TipoPaciente()
}